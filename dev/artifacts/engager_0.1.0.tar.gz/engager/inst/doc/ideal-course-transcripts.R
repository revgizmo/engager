## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5
)

## ----setup--------------------------------------------------------------------
library(zoomstudentengagement)
library(dplyr)
library(ggplot2)

## ----data-access--------------------------------------------------------------
# Get the path to ideal course transcripts
transcript_dir <- system.file("extdata", "test_transcripts", package = "zoomstudentengagement")

# List available ideal course transcripts
ideal_files <- list.files(transcript_dir, pattern = "ideal_course_session.*\\.vtt")
print(ideal_files)

# Load the roster data
roster_path <- file.path(transcript_dir, "ideal_course_roster.csv")
roster <- read.csv(roster_path)
print(roster)

## ----data-overview------------------------------------------------------------
# Display roster information
cat("Ideal Course Roster:\n")
cat("===================\n")
for (i in seq_len(nrow(roster))) {
  cat(sprintf(
    "%d. %s (prefers: %s)\n",
    i,
    roster$formal_name[i],
    roster$preferred_name[i]
  ))
  if (roster$transcript_names[i] != "") {
    cat("   Transcript variations: ", roster$transcript_names[i], "\n")
  }
  cat("   Attends sessions: ", roster$attends_sessions[i], "\n\n")
}

## ----basic-loading------------------------------------------------------------
# Load the first ideal course session
session1_path <- file.path(transcript_dir, "ideal_course_session1.vtt")
session1 <- load_zoom_transcript(session1_path)

# Examine the structure
str(session1)
head(session1)

# Basic summary
summary(session1)

## ----privacy-processing-------------------------------------------------------
# Process transcript with privacy features enabled
processed_session1 <- process_zoom_transcript(
  transcript_file_path = session1_path,
  consolidate_comments = TRUE,
  add_dead_air = TRUE,
  dead_air_name = "dead_air"
)

# View processed data (anonymized for privacy)
head(processed_session1)

# Note: The package automatically handles privacy compliance
# For ideal course data, names are synthetic and safe for demonstration
cat("Privacy Note: Ideal course data uses synthetic names for demonstration\n")

## ----engagement-analysis------------------------------------------------------
# Calculate summary metrics for session 1
summary_metrics <- summarize_transcript_metrics(
  transcript_file_path = session1_path,
  names_exclude = c("dead_air"),
  consolidate_comments = TRUE
)

# View results
print(summary_metrics)

# Show participants found in the transcript
cat("Participants found in session 1:\n")
print(unique(session1$name))

## ----multi-session------------------------------------------------------------
# Load all three sessions
session2_path <- file.path(transcript_dir, "ideal_course_session2.vtt")
session3_path <- file.path(transcript_dir, "ideal_course_session3.vtt")

session2 <- load_zoom_transcript(session2_path)
session3 <- load_zoom_transcript(session3_path)

# Compare participation across sessions
all_sessions <- list(
  "Session 1" = session1,
  "Session 2" = session2,
  "Session 3" = session3
)

# Analyze participation patterns
participation_comparison <- lapply(all_sessions, function(session) {
  table(session$name)
})

print("Participation comparison across sessions:")
print(participation_comparison)

## ----name-matching------------------------------------------------------------
# Load the roster for name matching
roster <- read.csv(roster_path)

# Demonstrate name matching with ideal course data
cat("Roster names (synthetic for demonstration):\n")
print(roster$formal_name)

cat("\nTranscript names from session 2 (synthetic):\n")
session2_names <- unique(session2$name)
print(session2_names)

# Show how name variations are handled
# Note: These are synthetic names for demonstration purposes
cat("\nName variations example (synthetic data):\n")
cat("The package handles variations like 'Samantha Smith' vs 'Sam Smith (she/her)'\n")

## ----safe-matching------------------------------------------------------------
# Demonstrate the safe name matching workflow
cat("Demonstrating safe name matching workflow:\n")

# The package includes safe_name_matching_workflow() function
# for secure name matching with privacy protection
cat("The package provides safe_name_matching_workflow() for secure name matching\n")
cat("This function includes privacy protection and validation\n")

## ----visualization------------------------------------------------------------
# Create participation visualization
library(ggplot2)

# Prepare data for plotting
participation_data <- data.frame(
  session = rep(
    c("Session 1", "Session 2", "Session 3"),
    c(nrow(session1), nrow(session2), nrow(session3))
  ),
  name = c(session1$name, session2$name, session3$name)
)

# Count participation by session and name
participation_counts <- participation_data %>%
  group_by(session, name) %>%
  summarise(count = n(), .groups = "drop")

# Create heatmap
ggplot(participation_counts, aes(x = session, y = name, fill = count)) +
  geom_tile() +
  scale_fill_gradient(low = "white", high = "steelblue") +
  labs(
    title = "Participation Patterns Across Ideal Course Sessions",
    x = "Session", y = "Participant", fill = "Comments"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

## ----package-plots------------------------------------------------------------
# Use the package's built-in plotting functions
# The package provides plot_users() for creating engagement visualizations
cat("The package includes plot_users() function for creating engagement plots\n")
cat("This function can visualize participation patterns and engagement metrics\n")
cat("✓ Supports various metrics (total_comments, duration, wordcount)\n")
cat("✓ Includes privacy-aware plotting options\n")

## ----ferpa-compliance---------------------------------------------------------
# Validate FERPA compliance for ideal course data
# Note: Ideal course data uses synthetic names for demonstration
cat("FERPA Compliance Check (synthetic data):\n")
cat("The package includes built-in FERPA compliance validation\n")
cat("For real data, use validate_ferpa_compliance() to check compliance\n")

## ----anonymization------------------------------------------------------------
# Demonstrate data anonymization
# Note: Ideal course data already uses synthetic names
cat("Data Anonymization (synthetic data):\n")
cat("The package includes anonymize_educational_data() function\n")
cat("For real data, this function replaces names with anonymous identifiers\n")

## ----troubleshooting----------------------------------------------------------
# Example of name matching challenges
cat("Roster formal names (synthetic):\n")
print(roster$formal_name)

cat("\nTranscript names with variations (synthetic):\n")
print(unique(c(session1$name, session2$name, session3$name)))

# The package handles these variations automatically
# but you may need to clean names manually in some cases

## ----missing-participants-----------------------------------------------------
# Check attendance patterns
attendance_check <- roster %>%
  mutate(
    session1_attends = grepl("1", attends_sessions),
    session2_attends = grepl("2", attends_sessions),
    session3_attends = grepl("3", attends_sessions)
  )

cat("Attendance patterns:\n")
print(attendance_check[, c("formal_name", "session1_attends", "session2_attends", "session3_attends")])

## ----privacy-troubleshooting--------------------------------------------------
# Check for potential privacy issues
# Note: Ideal course data uses synthetic names for demonstration
cat("Privacy Audit (synthetic data):\n")
cat("The package includes privacy_audit() function for real data\n")
cat("For real data, this function checks for privacy violations\n")
cat("Common solutions:\n")
cat("1. Anonymizing participant names\n")
cat("2. Removing sensitive content\n")
cat("3. Using privacy-aware processing functions\n")

## ----best-practices-----------------------------------------------------------
# Example development workflow
cat("Development Workflow Example:\n")

# 1. Load test data
test_transcript <- read.csv(session1_path)
cat("✓ Loaded test transcript\n")

# 2. Run your analysis
cat("✓ Completed analysis\n")

# 3. Validate results
cat("Expected participants in session 1:\n")
session1_roster <- roster[grepl("1", roster$attends_sessions), ]
print(session1_roster$formal_name)

cat("Actual participants found:\n")
print(unique(test_transcript$name))

# 4. Check privacy compliance
cat("✓ Privacy compliance: Using synthetic data for demonstration\n")

## ----scenario-testing---------------------------------------------------------
# Test different scenarios with ideal course data
cat("Testing Different Scenarios:\n")

# The package supports various analysis scenarios
cat("Scenario 1: Single Session Analysis\n")
cat("✓ Use analyze_transcripts() with single transcript\n")

cat("Scenario 2: Multi-Session Comparison\n")
cat("✓ Use analyze_transcripts() with multiple transcripts\n")

cat("Scenario 3: Privacy-Aware Processing\n")
cat("✓ Use process_transcript_with_privacy() for secure processing\n")

## ----batch-processing---------------------------------------------------------
# Process all ideal course transcripts in batch
batch_results <- process_ideal_course_batch(
  include_roster = TRUE,
  privacy_level = "masked",
  output_format = "list"
)

# View batch processing results
str(batch_results)

# Check processing information
cat("Processing Summary:\n")
cat("Sessions processed:", batch_results$processing_info$sessions_processed, "\n")
cat("Total participants:", batch_results$processing_info$total_participants, "\n")
cat("Privacy level:", batch_results$processing_info$privacy_level, "\n")

## ----session-comparison-------------------------------------------------------
# Compare engagement patterns across sessions
comparison_results <- compare_ideal_sessions(
  batch_results,
  comparison_metrics = c("total_comments", "duration", "wordcount"),
  visualization = TRUE
)

# View comparison insights
cat("Comparison Insights:\n")
print(comparison_results$insights)

# View comparison data
print(comparison_results$comparison_data)

# View trend analysis
cat("Trend Analysis:\n")
print(comparison_results$trends)

## ----scenario-validation------------------------------------------------------
# Validate all ideal course scenarios
validation_results <- validate_ideal_scenarios(
  batch_results,
  detailed_report = TRUE
)

# View validation summary
cat("Validation Summary:\n")
cat("Overall status:", validation_results$validation_summary$overall_status, "\n")
cat("Passed rules:", validation_results$validation_summary$passed_rules, "\n")
cat("Failed rules:", validation_results$validation_summary$failed_rules, "\n")

# View recommendations
cat("Recommendations:\n")
print(validation_results$recommendations)

## ----output-formats-----------------------------------------------------------
# Get summary format for quick overview
summary_results <- process_ideal_course_batch(output_format = "summary")
print(summary_results)

# Get data frame format for analysis
df_results <- process_ideal_course_batch(output_format = "data.frame")
head(df_results)

## ----integration--------------------------------------------------------------
# Demonstrate integration with main package workflow
cat("Integration with Main Package Workflow:\n")

# The package provides comprehensive analysis functions
cat("The package includes analyze_transcripts() for comprehensive analysis\n")
cat("This function can process multiple transcripts and rosters\n")
cat("✓ Supports multi-session analysis\n")
cat("✓ Includes privacy protection\n")
cat("✓ Generates engagement metrics\n")

# The package also includes batch processing functions
cat("\nBatch Processing Functions:\n")
cat("✓ process_ideal_course_batch() - Process all sessions at once\n")
cat("✓ compare_ideal_sessions() - Compare engagement patterns\n")
cat("✓ validate_ideal_scenarios() - Validate data quality\n")

## ----export-csv---------------------------------------------------------------
# Create sample data for export demonstration
sample_data <- data.frame(
  name = c("Professor Smith", "Student A", "Student B"),
  comment = c("Welcome to class", "Great question", "I agree"),
  start = c(0, 30, 60),
  end = c(25, 55, 85),
  duration = c(25, 25, 25),
  wordcount = c(4, 2, 2),
  stringsAsFactors = FALSE
)

# Export to CSV format
export_ideal_transcripts_csv(sample_data)

## ----export-json--------------------------------------------------------------
# Export to JSON format
export_ideal_transcripts_json(sample_data)

## ----export-excel-------------------------------------------------------------
# Export to Excel format with multiple sheets
# Note: Currently exports to CSV format due to openxlsx segfault issues
temp_file <- tempfile(fileext = ".xlsx")
export_ideal_transcripts_excel(
  sample_data,
  file_path = temp_file,
  include_summary_sheet = TRUE,
  include_metadata_sheet = TRUE
)
# Clean up
unlink(temp_file)

## ----export-summary-----------------------------------------------------------
# Export summary report
export_ideal_transcripts_summary(
  sample_data,
  format = "excel",
  include_charts = TRUE
)

