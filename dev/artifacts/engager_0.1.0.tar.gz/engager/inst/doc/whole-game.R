## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 8,
  fig.height = 6
)

## ----load-packages------------------------------------------------------------
library(zoomstudentengagement)
library(dplyr)
library(ggplot2)
library(readr)
library(tibble)

## ----explore-data-------------------------------------------------------------
# Check what transcript files are available (specifically .transcript.vtt files)
transcript_files <- list.files(
  system.file("extdata/transcripts", package = "zoomstudentengagement"),
  pattern = "\\.transcript\\.vtt$",
  full.names = TRUE
)

cat("Available transcript files:\n")
basename(transcript_files)

# Check what other data files are available
cat("\nAvailable data files:\n")
list.files(system.file("extdata", package = "zoomstudentengagement"))

## ----load-roster--------------------------------------------------------------
# Load the student roster
roster <- load_roster(
  data_folder = system.file("extdata", package = "zoomstudentengagement"),
  roster_file = "roster.csv"
)

# View the roster structure
head(roster)
cat("\nRoster dimensions:", nrow(roster), "students\n")

## ----load-transcripts---------------------------------------------------------
# Load a single transcript to see the structure
transcript_file <- system.file(
  "extdata/transcripts/GMT20240124-202901_Recording.transcript.vtt",
  package = "zoomstudentengagement"
)

# Load and process the transcript
transcript_data <- load_zoom_transcript(transcript_file)

# View the structure
head(transcript_data)
cat("\nTranscript dimensions:", nrow(transcript_data), "utterances\n")

## ----process-multiple---------------------------------------------------------
# Get all transcript files (specifically .transcript.vtt files)
transcript_files <- list.files(
  system.file("extdata/transcripts", package = "zoomstudentengagement"),
  pattern = "\\.transcript\\.vtt$",
  full.names = TRUE
)

# Process all transcripts
all_transcripts <- lapply(transcript_files, function(file) {
  cat("Processing:", basename(file), "\n")
  load_zoom_transcript(file)
})

# Combine all transcripts
combined_transcripts <- dplyr::bind_rows(all_transcripts, .id = "session")

cat("\nCombined data dimensions:", nrow(combined_transcripts), "utterances\n")

## ----calculate-metrics--------------------------------------------------------
# Calculate metrics for all transcript files
metrics <- summarize_transcript_files(
  transcript_file_names = basename(transcript_files),
  data_folder = system.file("extdata", package = "zoomstudentengagement"),
  transcripts_folder = "transcripts",
  names_to_exclude = c("dead_air", "Unknown")
)

# View the metrics
head(metrics)

## ----name-matching-overview---------------------------------------------------
# First, let's see what names appear in the transcripts
transcript_names <- unique(metrics$name)
cat("Names in transcripts:\n")
print(transcript_names)

# Compare with roster names
roster_names <- unique(roster$preferred_name)
cat("\nNames in roster:\n")
print(roster_names)

# Identify potential matching issues
unmatched_names <- setdiff(transcript_names, roster_names)
cat("\nNames that may need mapping:\n")
print(unmatched_names)

## ----create-mappings----------------------------------------------------------
# Create name mappings for unmatched names
name_mappings <- data.frame(
  transcript_name = c("Bob", "Sally", "Mike", "Guest User"),
  preferred_name = c("Robert Smith", "Sarah Johnson", "Michael Brown", "GUEST_001"),
  stringsAsFactors = FALSE
)

# Write the mapping file
write_section_names_lookup(name_mappings, ".", "section_names_lookup.csv")

# Verify the file was created
cat("Mapping file created successfully\n")
file.exists("section_names_lookup.csv")

## ----safe-workflow------------------------------------------------------------
# Pure participant classification prior to metrics
lookup_path <- "section_names_lookup.csv"
lookup_df <- read_lookup_safely(lookup_path)
set_privacy_defaults(privacy_level = "ferpa_standard")
classified <- classify_participants(
  transcript_df = transcript_data,
  roster_df = roster,
  lookup_df = lookup_df,
  privacy_level = "ferpa_standard"
)

cat("Classification completed. Records:", nrow(classified), "\n")

## ----guest-users--------------------------------------------------------------
# Map guest users to standardized identifiers
guest_mappings <- data.frame(
  transcript_name = c("Guest User", "Unknown User", "Guest-1234"),
  preferred_name = c("GUEST_001", "GUEST_002", "GUEST_003"),
  stringsAsFactors = FALSE
)

## ----custom-names-------------------------------------------------------------
# Map custom names to official roster names
custom_mappings <- data.frame(
  transcript_name = c("JS", "Dr. Smith", "JohnS"),
  preferred_name = c("John Smith", "John Smith", "John Smith"),
  stringsAsFactors = FALSE
)

## ----name-variations----------------------------------------------------------
# Handle name variations across sessions
variation_mappings <- data.frame(
  transcript_name = c("John Smith", "J. Smith", "Smith, John"),
  preferred_name = c("John Smith", "John Smith", "John Smith"),
  stringsAsFactors = FALSE
)

## ----clean-engagement---------------------------------------------------------
# For this example, we'll use the safe name matching workflow
# which handles the mapping automatically with privacy protection

# Create a simple example with the data we have
example_metrics <- data.frame(
  name = c("John Smith", "Jane Doe", "Guest User"),
  n = c(5, 3, 1),
  duration = c(120, 90, 30),
  wordcount = c(50, 30, 10),
  wpm = c(25, 20, 20),
  stringsAsFactors = FALSE
)

# Apply simple name cleaning (in practice, use safe_name_matching_workflow)
clean_metrics <- example_metrics %>%
  mutate(
    student_name = ifelse(name == "Guest User", "GUEST_001", name),
    is_matched = name != "Guest User"
  )

# View the results
head(clean_metrics)

# Summary of matching success
matching_summary <- clean_metrics %>%
  group_by(is_matched) %>%
  summarise(
    count = n(),
    percentage = n() / nrow(clean_metrics) * 100
  )

print(matching_summary)

## ----analyze-patterns---------------------------------------------------------
# Create a summary by student
student_summary <- clean_metrics %>%
  group_by(student_name) %>%
  summarise(
    total_utterances = sum(n, na.rm = TRUE),
    total_duration = sum(duration, na.rm = TRUE),
    total_words = sum(wordcount, na.rm = TRUE),
    avg_words_per_minute = mean(wpm, na.rm = TRUE),
    participation_rate = total_utterances / nrow(clean_metrics) * 100
  ) %>%
  arrange(desc(total_utterances))

# View the summary
head(student_summary, 10)

## ----visualize-participation--------------------------------------------------
# Plot participation by utterance count
ggplot(student_summary, aes(x = reorder(student_name, total_utterances), y = total_utterances)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  coord_flip() +
  labs(
    title = "Student Participation by Utterance Count",
    x = "Student Name",
    y = "Number of Utterances"
  ) +
  theme_minimal()

# Plot participation by duration
ggplot(student_summary, aes(x = reorder(student_name, total_duration), y = total_duration / 60)) +
  geom_bar(stat = "identity", fill = "darkgreen") +
  coord_flip() +
  labs(
    title = "Student Participation by Speaking Time",
    x = "Student Name",
    y = "Speaking Time (minutes)"
  ) +
  theme_minimal()

## ----identify-gaps------------------------------------------------------------
# Identify students with low participation
low_participation <- student_summary %>%
  filter(total_utterances < median(total_utterances, na.rm = TRUE)) %>%
  arrange(total_utterances)

cat("Students with below-median participation:\n")
print(low_participation[, c("student_name", "total_utterances", "total_duration")])

# Calculate participation equity metrics
participation_stats <- student_summary %>%
  summarise(
    mean_utterances = mean(total_utterances, na.rm = TRUE),
    median_utterances = median(total_utterances, na.rm = TRUE),
    sd_utterances = sd(total_utterances, na.rm = TRUE),
    gini_coefficient = (2 * sum(rank(total_utterances) * total_utterances) /
      (n() * sum(total_utterances))) - (n() + 1) / n()
  )

cat("\nParticipation Statistics:\n")
print(participation_stats)

## ----actionable-insights------------------------------------------------------
# Create participation categories
participation_categories <- student_summary %>%
  mutate(
    participation_level = case_when(
      total_utterances >= quantile(total_utterances, 0.75, na.rm = TRUE) ~ "High",
      total_utterances >= quantile(total_utterances, 0.25, na.rm = TRUE) ~ "Medium",
      TRUE ~ "Low"
    )
  )

# Summary by participation level
level_summary <- participation_categories %>%
  group_by(participation_level) %>%
  summarise(
    count = n(),
    percentage = n() / nrow(participation_categories) * 100
  )

cat("Participation Level Distribution:\n")
print(level_summary)

# Recommendations based on analysis
cat("\n=== RECOMMENDATIONS FOR EQUITABLE PARTICIPATION ===\n")
cat("1. Students with low participation may benefit from:\n")
cat("   - Direct invitations to contribute\n")
cat("   - Smaller group discussions\n")
cat("   - Alternative participation methods (chat, polls)\n\n")

cat("2. Consider implementing:\n")
cat("   - Structured discussion protocols\n")
cat("   - Think-pair-share activities\n")
cat("   - Anonymous participation options\n\n")

cat("3. Monitor participation patterns over time to:\n")
cat("   - Track improvement in engagement\n")
cat("   - Identify effective interventions\n")
cat("   - Ensure all students feel included\n")

## ----ferpa-compliance---------------------------------------------------------
# Validate your data for FERPA compliance
compliance_result <- validate_ferpa_compliance(
  student_summary,
  institution_type = "educational"
)

# Check compliance status
cat("FERPA Compliance Status:", ifelse(compliance_result$compliant, "COMPLIANT", "NON-COMPLIANT"), "\n")

if (!compliance_result$compliant) {
  cat("\n⚠️  Compliance Issues Found:\n")
  cat("PII detected in columns:", paste(compliance_result$pii_detected, collapse = ", "), "\n")
  cat("\nRecommendations:\n")
  cat(paste("- ", compliance_result$recommendations, collapse = "\n"), "\n")

  # Anonymize data if needed
  cat("\n🔒 Anonymizing data for compliance...\n")
  anonymized_summary <- anonymize_educational_data(
    student_summary,
    method = "mask"
  )
} else {
  cat("✅ Data is FERPA compliant\n")
  anonymized_summary <- student_summary
}

# Generate compliance report
compliance_report <- generate_ferpa_report(
  student_summary,
  output_file = "ferpa_compliance_report.json",
  report_format = "json"
)

cat("\n📋 FERPA compliance report generated: ferpa_compliance_report.json\n")

## ----save-analysis------------------------------------------------------------
# Save the clean metrics (privacy-safe)
write_csv(clean_metrics, "clean_engagement_metrics.csv")

# Save the student summary (privacy-safe)
write_csv(anonymized_summary, "student_participation_summary.csv")

# Save the name mappings for future use
write_csv(name_mappings, "name_mappings.csv")

cat("Analysis files saved:\n")
cat("- clean_engagement_metrics.csv\n")
cat("- student_participation_summary.csv (privacy-safe)\n")
cat("- name_mappings.csv\n")
cat("- ferpa_compliance_report.json\n")

