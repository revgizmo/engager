## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----essential-functions------------------------------------------------------
library(engager)

# Get list of exported functions (essential functions)
exported_functions <- names(getNamespaceExports("engager"))
essential_functions <- exported_functions[!exported_functions %in% c("%>%")] # Exclude pipe operator
cat("Essential functions (", length(essential_functions), "):\n")
cat(paste("-", essential_functions), sep = "\n")

## ----load-transcript----------------------------------------------------------
# Load a sample transcript
transcript_file <- system.file("extdata/transcripts/GMT20240124-202901_Recording.transcript.vtt",
  package = "engager"
)

# Load the transcript
transcript <- load_zoom_transcript(transcript_file)
cat("Transcript loaded with", nrow(transcript), "comments\n")

## ----process-transcript-------------------------------------------------------
# Process transcript with privacy defaults
processed <- process_zoom_transcript(
  transcript_df = transcript,
  add_dead_air = TRUE,
  consolidate_comments = TRUE
)

cat("Processed transcript has", nrow(processed), "rows\n")

## ----analyze-engagement-------------------------------------------------------
# Analyze transcripts for engagement metrics
# Note: This would normally analyze actual transcript files
# For this example, we'll demonstrate the function call structure
cat("analyze_transcripts() would analyze all .vtt files in the specified folder\n")
cat("Function signature: analyze_transcripts(transcripts_folder, names_to_exclude, write, output_path)\n")

## ----privacy-compliance-------------------------------------------------------
# Check privacy compliance with synthetic data
synthetic_data <- data.frame(
  name = c("Student A", "Student B", "Instructor"),
  message = c("Hello", "Good morning", "Welcome to class"),
  timestamp = c("00:01:00", "00:02:00", "00:00:30")
)

# Note: Privacy compliance functions would check for real names in data
cat("Privacy compliance functions validate that no real names are exposed\n")
cat("validate_privacy_compliance() and validate_ferpa_compliance() ensure FERPA compliance\n")

