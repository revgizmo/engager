## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5
)

## ----setup--------------------------------------------------------------------
library(engager)
library(dplyr)
library(ggplot2)

## ----eval = FALSE-------------------------------------------------------------
# devtools::install_github("revgizmo/engager")

## ----quick-start--------------------------------------------------------------
# Load a sample transcript
transcript_file <- system.file(
  "extdata/transcripts/GMT20240124-202901_Recording.transcript.vtt",
  package = "engager"
)

# Process the transcript
processed_transcript <- process_zoom_transcript(
  transcript_file_path = transcript_file,
  consolidate_comments = TRUE,
  add_dead_air = TRUE
)

# Calculate summary metrics
summary_metrics <- summarize_transcript_metrics(
  transcript_file_path = transcript_file,
  names_exclude = c("dead_air")
)

# View the results (privacy-safe by default)
head(summary_metrics)

# Check privacy compliance
privacy_result <- privacy_audit(summary_metrics)
cat("Privacy Check:", ifelse(nrow(privacy_result) == 0, "✅ No issues found", "⚠️  Issues found"), "\n")

## ----name-matching-example----------------------------------------------------
# Example: Create name mappings
name_mappings <- data.frame(
  transcript_name = c("JS", "Dr. Smith", "Guest User"),
  preferred_name = c("John Smith", "John Smith", "GUEST_001"),
  stringsAsFactors = FALSE
)

# Write the mapping file
readr::write_csv(name_mappings, "section_names_lookup.csv")

## ----guest-users--------------------------------------------------------------
# Map guest users to consistent identifiers
guest_mappings <- data.frame(
  transcript_name = c("Guest User", "Unknown User", "Guest-1234"),
  preferred_name = c("GUEST_001", "GUEST_002", "GUEST_003"),
  stringsAsFactors = FALSE
)

## ----custom-names-------------------------------------------------------------
# Map custom names to official roster names
custom_mappings <- data.frame(
  transcript_name = c("JS", "JohnS", "jsmith"),
  preferred_name = c("John Smith", "John Smith", "John Smith"),
  stringsAsFactors = FALSE
)

