## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5
)

## ----setup, include = FALSE---------------------------------------------------
library(zoomstudentengagement)

## -----------------------------------------------------------------------------
# Example section_names_lookup.csv for guest users
guest_mapping <- data.frame(
  transcript_name = c("Guest User", "Unknown User", "Guest-1234"),
  preferred_name = c("GUEST_001", "GUEST_002", "GUEST_003"),
  stringsAsFactors = FALSE
)

# Write the mapping file (safe transactional helper)
write_lookup_transactional(
  df = read_lookup_safely("section_names_lookup.csv") |> merge_lookup_preserve(guest_mapping),
  path = "section_names_lookup.csv"
)

## -----------------------------------------------------------------------------
# Example section_names_lookup.csv for custom names
custom_mapping <- data.frame(
  transcript_name = c("JS", "Dr. Smith", "JohnS", "jsmith"),
  preferred_name = c("John Smith", "John Smith", "John Smith", "John Smith"),
  stringsAsFactors = FALSE
)

# Write the mapping file (safe transactional helper)
write_lookup_transactional(
  df = read_lookup_safely("section_names_lookup.csv") |> merge_lookup_preserve(custom_mapping),
  path = "section_names_lookup.csv"
)

## -----------------------------------------------------------------------------
# Example section_names_lookup.csv for cross-session consistency
cross_session_mapping <- data.frame(
  transcript_name = c("John Smith", "J. Smith", "Smith, John", "JohnS"),
  preferred_name = c("John Smith", "John Smith", "John Smith", "John Smith"),
  stringsAsFactors = FALSE
)

# Write the mapping file (safe transactional helper)
# Note: In vignettes, we use a temporary path to avoid writing to vignette directory
temp_lookup_path <- tempfile(fileext = ".csv")
write_lookup_transactional(
  df = read_lookup_safely(temp_lookup_path) |> merge_lookup_preserve(cross_session_mapping),
  path = temp_lookup_path
)
# Clean up
unlink(temp_lookup_path)

## -----------------------------------------------------------------------------
# Example section_names_lookup.csv for name variations
variation_mapping <- data.frame(
  transcript_name = c("John Smith", "Smith, John", "J. Smith", "John S.", "Smith"),
  preferred_name = c("John Smith", "John Smith", "John Smith", "John Smith", "John Smith"),
  stringsAsFactors = FALSE
)

# Write the mapping file (safe transactional helper)
# Note: In vignettes, we use a temporary path to avoid writing to vignette directory
temp_lookup_path <- tempfile(fileext = ".csv")
write_lookup_transactional(
  df = read_lookup_safely(temp_lookup_path) |> merge_lookup_preserve(variation_mapping),
  path = temp_lookup_path
)
# Clean up
unlink(temp_lookup_path)

## -----------------------------------------------------------------------------
# Example error message
# Error: Found unmatched names: Guest User, JS, Dr. Smith
# Please update your section_names_lookup.csv file with these mappings.

## -----------------------------------------------------------------------------
# Required columns
required_structure <- data.frame(
  transcript_name = "Name from Zoom transcript",
  preferred_name = "Name from your roster",
  stringsAsFactors = FALSE
)

## -----------------------------------------------------------------------------
# Example: Adding mappings for unmatched names
new_mappings <- data.frame(
  transcript_name = c("Guest User", "JS", "Dr. Smith"),
  preferred_name = c("GUEST_001", "John Smith", "John Smith"),
  stringsAsFactors = FALSE
)

# Append to existing file or create new one
write_section_names_lookup(new_mappings, ".", "section_names_lookup.csv")

## -----------------------------------------------------------------------------
# Load your data (using example files for demonstration)
transcript_file <- system.file(
  "extdata/transcripts/GMT20240124-202901_Recording.transcript.vtt",
  package = "zoomstudentengagement"
)
roster_data <- load_roster(
  data_folder = system.file("extdata", package = "zoomstudentengagement"),
  roster_file = "roster.csv"
)

# Run analysis with name matching (this will demonstrate the error handling)
tryCatch(
  {
    results <- safe_name_matching_workflow(
      transcript_file_path = transcript_file,
      roster_data = roster_data,
      section_names_lookup_file = "section_names_lookup.csv"
    )
    cat("Name matching completed successfully!\n")
  },
  error = function(e) {
    cat("Expected error encountered:\n")
    cat(e$message, "\n")
    cat("\nThis demonstrates the privacy-first approach in action.\n")
  }
)

## -----------------------------------------------------------------------------
# Check if file exists
file.exists("section_names_lookup.csv")

# Create file if it doesn't exist
if (!file.exists("section_names_lookup.csv")) {
  empty_mapping <- data.frame(
    transcript_name = character(0),
    preferred_name = character(0),
    stringsAsFactors = FALSE
  )
  write_section_names_lookup(empty_mapping, ".", "section_names_lookup.csv")
}

## -----------------------------------------------------------------------------
# Check file structure (example)
mapping_data <- data.frame(
  transcript_name = c("JS", "Dr. Smith"),
  preferred_name = c("John Smith", "John Smith"),
  stringsAsFactors = FALSE
)
names(mapping_data)

# Should show: [1] "transcript_name" "preferred_name"

## -----------------------------------------------------------------------------
# Check roster data (example)
roster_data <- data.frame(
  preferred_name = c("John Smith", "Jane Doe"),
  stringsAsFactors = FALSE
)
nrow(roster_data)

# Should be greater than 0

## -----------------------------------------------------------------------------
# Check transcript structure (example)
transcript_data <- data.frame(
  user_name = c("John Smith", "Jane Doe"),
  message = c("Hello", "Hi there"),
  timestamp = Sys.time(),
  stringsAsFactors = FALSE
)
names(transcript_data)

# Expected columns: user_name, message, timestamp, etc.

## -----------------------------------------------------------------------------
# Set privacy level (default is "mask")
set_privacy_defaults(privacy_level = "mask")

# Available options:
# - "mask": Names are hashed in outputs (recommended)
# - "none": Names appear as-is (use with caution)

## -----------------------------------------------------------------------------
# Load multiple transcripts (example)
transcript_files <- list.files("transcripts/", pattern = "*.vtt", full.names = TRUE)

# Process each file with the same mapping
for (file in transcript_files) {
  transcript_data <- load_zoom_transcript(file)
  results <- safe_name_matching_workflow(
    transcript_file_path = file,
    roster_data = roster_data,
    section_names_lookup_file = "section_names_lookup.csv"
  )
  # Process results...
}

