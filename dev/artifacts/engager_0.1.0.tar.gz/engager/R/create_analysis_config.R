# Internal function - no documentation needed
create_analysis_config <- function(
    # Course Information
    dept = "LTF",
    semester_start_mdy = "Jan 01, 2024",
    scheduled_session_length_hours = 1.5,
    instructor_name = "Conor Healy",
    # File Paths
    data_folder = system.file("extdata", package = "engager"),
    transcripts_folder = "transcripts",
    roster_file = "roster.csv",
    cancelled_classes_file = "cancelled_classes.csv",
    names_lookup_file = "section_names_lookup.csv",
    trnscrptssssnsmmryfl = "transcripts_session_summary.csv",
    transcripts_summary_file = "transcripts_summary.csv",
    # Report Settings
    student_summary_report = "Zoom_Student_Engagement_Analysis_student_summary_report",
    student_summary_report_folder = system.file("", package = "engager"),
    # File Patterns
    topic_split_pattern = paste0(
      "^(?<dept>\\S+) (?<section>\\S+) - ",
      "(?<day>[A-Za-z]+) (?<time>\\S+\\s*\\S+) (?<instructor>\\(.*?\\))"
    ),
    zmrcrddsssnscsvnmspttrn = "zoomus_recordings__\\d{8}(?:\\s+copy\\s*\\d*)?\\.csv",
    zmrcrddsssnscsvclnms = paste0(
      "Topic,ID,Start Time,File Size (MB),File Count,",
      "Total Views,Total Downloads,Last Accessed"
    ),
    # Transcript File Patterns
    transcript_files_names_pattern = "GMT\\d{8}-\\d{6}_Recording",
    dt_extract_pattern = "(?<=GMT)\\d{8}",
    trnscrptflxtnsnpttrn = ".transcript",
    clsdcptnflxtnsnpttrn = ".cc",
    recording_start_pattern = "(?<=GMT)\\d{8}-\\d{6}",
    recording_start_format = "%Y%m%d-%H%M%S",
    start_time_local_tzone = "America/Los_Angeles",
    # Column Types
    cancelled_classes_col_types = "ciiiccccccdiiicTTcTTccci",
    section_names_lookup_col_types = "ccccccccc",
    # Analysis Parameters
    names_to_exclude = NULL,
    # Session Mapping
    use_session_mapping = FALSE,
    session_mapping_file = "session_mapping.csv") {
  # DEPRECATED: This function will be removed in the next version
  # Use essential functions instead. See ?get_essential_functions for alternatives.
  warning(
    "Function 'create_analysis_config' is deprecated and will be removed in the next version. ",
    "Please use the essential functions instead. See ?get_essential_functions for alternatives.",
    call. = FALSE
  )

  # Validate inputs
  if (!is.character(dept) || length(dept) != 1) {
    stop("dept must be a single character string")
  }

  if (!is.character(semester_start_mdy) || length(semester_start_mdy) != 1) {
    stop("semester_start_mdy must be a single character string")
  }

  if (!is.numeric(scheduled_session_length_hours) ||
    length(scheduled_session_length_hours) != 1 ||
    scheduled_session_length_hours <= 0) {
    stop("scheduled_session_length_hours must be a positive number")
  }

  if (!is.character(instructor_name) || length(instructor_name) != 1) {
    stop("instructor_name must be a single character string")
  }

  if (!is.character(data_folder) || length(data_folder) != 1) {
    stop("data_folder must be a single character string")
  }

  if (!is.character(transcripts_folder) || length(transcripts_folder) != 1) {
    stop("transcripts_folder must be a single character string")
  }

  if (!is.character(roster_file) || length(roster_file) != 1) {
    stop("roster_file must be a single character string")
  }

  if (!is.character(cancelled_classes_file) || length(cancelled_classes_file) != 1) {
    stop("cancelled_classes_file must be a single character string")
  }

  if (!is.character(names_lookup_file) || length(names_lookup_file) != 1) {
    stop("names_lookup_file must be a single character string")
  }

  if (!is.character(trnscrptssssnsmmryfl) || length(trnscrptssssnsmmryfl) != 1) {
    stop("transcripts_session_summary_file must be a single character string")
  }

  if (!is.character(transcripts_summary_file) || length(transcripts_summary_file) != 1) {
    stop("transcripts_summary_file must be a single character string")
  }

  if (!is.character(student_summary_report) || length(student_summary_report) != 1) {
    stop("student_summary_report must be a single character string")
  }

  if (!is.character(student_summary_report_folder) || length(student_summary_report_folder) != 1) {
    stop("student_summary_report_folder must be a single character string")
  }

  if (!is.character(topic_split_pattern) || length(topic_split_pattern) != 1) {
    stop("topic_split_pattern must be a single character string")
  }

  if (!is.character(zmrcrddsssnscsvnmspttrn) || length(zmrcrddsssnscsvnmspttrn) != 1) {
    stop("zoom_recorded_sessions_csv_names_pattern must be a single character string")
  }

  if (!is.character(zmrcrddsssnscsvclnms) || length(zmrcrddsssnscsvclnms) != 1) {
    stop("zoom_recorded_sessions_csv_col_names must be a single character string")
  }

  if (!is.character(transcript_files_names_pattern) || length(transcript_files_names_pattern) != 1) {
    stop("transcript_files_names_pattern must be a single character string")
  }

  if (!is.character(dt_extract_pattern) || length(dt_extract_pattern) != 1) {
    stop("dt_extract_pattern must be a single character string")
  }

  if (!is.character(trnscrptflxtnsnpttrn) || length(trnscrptflxtnsnpttrn) != 1) {
    stop("transcript_file_extension_pattern must be a single character string")
  }

  if (!is.character(clsdcptnflxtnsnpttrn) || length(clsdcptnflxtnsnpttrn) != 1) {
    stop("closed_caption_file_extension_pattern must be a single character string")
  }

  if (!is.character(recording_start_pattern) || length(recording_start_pattern) != 1) {
    stop("recording_start_pattern must be a single character string")
  }

  if (!is.character(recording_start_format) || length(recording_start_format) != 1) {
    stop("recording_start_format must be a single character string")
  }

  if (!is.character(start_time_local_tzone) || length(start_time_local_tzone) != 1) {
    stop("start_time_local_tzone must be a single character string")
  }

  if (!is.character(cancelled_classes_col_types) || length(cancelled_classes_col_types) != 1) {
    stop("cancelled_classes_col_types must be a single character string")
  }

  if (!is.character(section_names_lookup_col_types) || length(section_names_lookup_col_types) != 1) {
    stop("section_names_lookup_col_types must be a single character string")
  }

  if (!is.logical(use_session_mapping) || length(use_session_mapping) != 1) {
    stop("use_session_mapping must be a single logical value")
  }

  if (!is.character(session_mapping_file) || length(session_mapping_file) != 1) {
    stop("session_mapping_file must be a single character string")
  }

  # Return full configuration object as expected by tests
  list(
    course = list(
      dept = dept,
      semester_start = semester_start_mdy,
      session_length_hours = scheduled_session_length_hours,
      instructor_name = instructor_name
    ),
    paths = list(
      data_folder = data_folder,
      transcripts_folder = transcripts_folder,
      roster_file = roster_file,
      cancelled_classes_file = cancelled_classes_file,
      names_lookup_file = names_lookup_file,
      transcripts_session_summary_file = trnscrptssssnsmmryfl,
      transcripts_summary_file = transcripts_summary_file
    ),
    patterns = list(
      topic_split = topic_split_pattern,
      zoom_recordings_csv = zmrcrddsssnscsvnmspttrn,
      zoom_recordings_csv_col_names = zmrcrddsssnscsvclnms,
      transcript_files_names = transcript_files_names_pattern,
      dt_extract = dt_extract_pattern,
      transcript_file_extension = trnscrptflxtnsnpttrn,
      closed_caption_file_extension = clsdcptnflxtnsnpttrn,
      recording_start = recording_start_pattern,
      recording_start_format = recording_start_format,
      start_time_local_tzone = start_time_local_tzone
    ),
    reports = list(
      student_summary_report = student_summary_report,
      student_summary_report_folder = student_summary_report_folder
    ),
    analysis = list(
      cancelled_classes_col_types = cancelled_classes_col_types,
      section_names_lookup_col_types = section_names_lookup_col_types,
      names_to_exclude = names_to_exclude
    ),
    session_mapping = list(
      use_session_mapping = use_session_mapping,
      session_mapping_file = session_mapping_file
    )
  )
}
