test_that("load_zoom_transcript loads valid VTT file correctly", {
  # Create a temporary VTT file
  vtt_content <- c(
    "WEBVTT",
    "",
    "1",
    "00:00:00.000 --> 00:00:03.000",
    "Student1: Hello",
    "",
    "2",
    "00:00:05.000 --> 00:00:08.000",
    "Student2: Hi there",
    "",
    "3",
    "00:00:10.000 --> 00:00:13.000",
    "Student1: How are you?"
  )

  temp_file <- tempfile(fileext = ".vtt")
  writeLines(vtt_content, temp_file)

  # Test loading the file
  result <- load_zoom_transcript(temp_file)

  # Check basic structure
  expect_s3_class(result, "tbl_df")
  expect_true(all(c("transcript_file", "comment_num", "name", "comment", "start", "end", "duration", "wordcount") %in% names(result)))

  # Check content
  expect_equal(nrow(result), 3)
  expect_equal(result$name, c("Student1", "Student2", "Student1"))
  expect_equal(result$comment, c("Hello", "Hi there", "How are you?"))
  expect_equal(unname(result$wordcount), c(1, 2, 3))

  # Check time handling
  expect_s3_class(result$start, "hms")
  expect_s3_class(result$end, "hms")
  expect_equal(as.numeric(result$duration), c(3, 3, 3))

  # Clean up
  unlink(temp_file)
})

test_that("load_zoom_transcript handles non-existent file", {
  # Test with non-existent file
  expect_error(
    load_zoom_transcript("nonexistent_file.vtt"),
    "file.exists\\(transcript_file_path\\) is not TRUE"
  )
})

test_that("load_zoom_transcript handles malformed VTT file", {
  # Create a malformed VTT file
  malformed_content <- c(
    "WEBVTT",
    "",
    "1",
    "00:00:00.000 --> 00:00:03.000", # Missing comment
    "",
    "2",
    "00:00:05.000 --> 00:00:08.000",
    "Student2: Hi there"
  )

  temp_file <- tempfile(fileext = ".vtt")
  writeLines(malformed_content, temp_file)

  # Test loading the file
  result <- load_zoom_transcript(temp_file)

  # Check that it handles the malformed entry gracefully
  expect_s3_class(result, "tbl_df")
  expect_equal(nrow(result), 1) # Only one valid entry

  # Clean up
  unlink(temp_file)
})

test_that("load_zoom_transcript handles empty VTT file", {
  # Create an empty VTT file
  empty_content <- c("WEBVTT", "")

  temp_file <- tempfile(fileext = ".vtt")
  writeLines(empty_content, temp_file)

  # Test loading the file
  result <- load_zoom_transcript(temp_file)

  # Check that it returns NULL for empty files
  expect_null(result)

  # Clean up
  unlink(temp_file)
})

test_that("load_zoom_transcript handles comments without names", {
  # Create a VTT file with unnamed comments
  vtt_content <- c(
    "WEBVTT",
    "",
    "1",
    "00:00:00.000 --> 00:00:03.000",
    "Hello", # No name
    "",
    "2",
    "00:00:05.000 --> 00:00:08.000",
    "Student2: Hi there"
  )

  temp_file <- tempfile(fileext = ".vtt")
  writeLines(vtt_content, temp_file)

  # Test loading the file
  result <- load_zoom_transcript(temp_file)

  # Check that it handles unnamed comments correctly
  expect_s3_class(result, "tbl_df")
  expect_equal(nrow(result), 2)
  expect_true(is.na(result$name[1])) # First comment should have NA name

  # Clean up
  unlink(temp_file)
})

test_that("load_zoom_transcript handles VTT file with insufficient entries", {
  # Create a VTT file with only 1 line after WEBVTT header (not enough for a complete entry)
  temp_file <- tempfile(fileext = ".vtt")
  writeLines(c("WEBVTT", "1"), temp_file)
  on.exit(unlink(temp_file), add = TRUE)

  # Should return NULL when there aren't enough lines for complete entries
  result <- load_zoom_transcript(temp_file)
  expect_null(result)
})

test_that("load_zoom_transcript errors on missing WEBVTT header", {
  temp_file <- tempfile(fileext = ".vtt")
  writeLines(c("NOTVTT", "", "1", "00:00:00.000 --> 00:00:01.000", "Student1: Hi"), temp_file)
  on.exit(unlink(temp_file), add = TRUE)
  expect_error(load_zoom_transcript(temp_file), "Invalid VTT")
})

test_that("load_zoom_transcript skips entries with invalid timestamps", {
  vtt_content <- c(
    "WEBVTT",
    "",
    "1",
    "00:00:00.000 --> 00:00:03.000",
    "Student1: Hello",
    "",
    "2",
    "00:00:05.000 --> not_a_time",
    "Student2: Bad time",
    "",
    "3",
    "00:00:06.000 --> 00:00:04.000",
    "Student3: Reversed times"
  )
  temp_file <- tempfile(fileext = ".vtt")
  writeLines(vtt_content, temp_file)
  on.exit(unlink(temp_file), add = TRUE)

  result <- load_zoom_transcript(temp_file)

  # Only the first entry should be valid
  expect_equal(nrow(result), 1)
  expect_equal(result$name, "Student1")
})

test_that("load_zoom_transcript handles missing timestamp separator", {
  vtt_content <- c(
    "WEBVTT",
    "",
    "1",
    "00:00:00.000 00:00:03.000",
    "Student1: Hello"
  )
  temp_file <- tempfile(fileext = ".vtt")
  writeLines(vtt_content, temp_file)
  on.exit(unlink(temp_file), add = TRUE)

  result <- load_zoom_transcript(temp_file)
  expect_null(result)
})

test_that("load_zoom_transcript handles large transcripts", {
  build_time <- function(sec) {
    hrs <- sec %/% 3600
    mins <- (sec %% 3600) %/% 60
    secs <- sec %% 60
    sprintf("%02d:%02d:%02d.000", hrs, mins, secs)
  }
  entries <- 1000
  lines <- c("WEBVTT", "")
  for (i in seq_len(entries)) {
    start_sec <- (i - 1) * 2
    end_sec <- start_sec + 1
    lines <- c(
      lines,
      as.character(i),
      paste0(build_time(start_sec), " --> ", build_time(end_sec)),
      paste0("Student", i, ": Comment ", i),
      ""
    )
  }
  temp_file <- tempfile(fileext = ".vtt")
  writeLines(lines, temp_file)
  on.exit(unlink(temp_file), add = TRUE)
  result <- load_zoom_transcript(temp_file)
  expect_equal(nrow(result), entries)
})
